import torch
import cv2
from mtcnn import MTCNN
import matplotlib.pyplot as plt
from facenet_pytorch import InceptionResnetV1
from torchvision import transforms
import numpy as np

class PreprocessingImage:
    def __init__(self, reshape=(128, 128)):
        self.detector = MTCNN()
        self.reshape = reshape

    def preprocessing(self, image):

        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = self.detector.detect_faces(image)

        face_imgs = []
        if results:
            for face in results:
                x, y, width, height = face['box']
                x, y = abs(x), abs(y)
                face_img = image[y:y+height, x:x+width]
                face_img = cv2.resize(face_img, self.reshape, interpolation=cv2.INTER_AREA)
                face_img = face_img.astype("float32") / 255.0
                face_imgs.append(face_img)


        return face_imgs 


class PredictingEmbedding:
    def __init__(self, device="cpu"):

        self.device = device
        self.model = InceptionResnetV1(pretrained='vggface2').eval().to(self.device)

        self.transform = transforms.Compose([
            transforms.Lambda(lambda x: (x * 255).astype(np.uint8) if x.dtype == np.float32 else x),
            transforms.ToPILImage(),
            transforms.Resize((128, 128)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5],
                                 std=[0.5, 0.5, 0.5])
        ])

    def extracting_embedding(self, image):
        image_tensor = self.transform(image)
        image_tensor = image_tensor.unsqueeze(0).to(self.device)
        with torch.no_grad():
            features = self.model(image_tensor)
        features = features.squeeze().cpu().numpy()
        return features



def normalize(vector):
    norm = np.linalg.norm(vector)
    return vector if norm == 0 else vector / norm


def cosine_similarity(face1, face2):
    f1 = normalize(face1)
    f2 = normalize(face2)
    similarity = np.dot(f1, f2)
    return similarity
