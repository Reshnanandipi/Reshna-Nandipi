from flask import Flask, request, render_template, Response, jsonify,redirect, url_for, flash,session
from werkzeug.security import generate_password_hash, check_password_hash

from flask_cors import CORS
from flask_mysqldb import MySQL
import cv2
import numpy as np
import base64
import re
import json
import threading
import time as another_time
from datetime import datetime,time, timedelta

from preprocessing import PreprocessingImage, PredictingEmbedding, normalize, cosine_similarity

app = Flask(__name__)
CORS(app)

app.config['SECRET_KEY'] = "SomeJwtTokenkvghtcugihji"
app.config['MYSQL_HOST'] = "localhost"
app.config['MYSQL_USER'] = "root"
app.config['MYSQL_PASSWORD'] = "root"
app.config['MYSQL_DB'] = "facedb"
mysql = MySQL(app=app)

try:
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT 1") 
    print("MySQL connected successfully.")
except Exception as e:
    print(f"MySQL connection failed: {e}")

image_preprocessing = PreprocessingImage()
pred_emb = PredictingEmbedding()

camera = cv2.VideoCapture(0)
face_frame = None
lock = threading.Lock()
seen_ids = set()


def get_current_period():
    now = datetime.now().time()
    #print("Current time:", now)  # Debugging current time

    if time(9, 0) <= now < time(10, 0):
        return "Period 1"
    elif time(10, 0) <= now < time(11, 0):
        return "Period 2"
    elif time(11, 0) <= now < time(12, 0):
        return "Period 3"
    elif time(12, 0) <= now < time(13, 0):
        return "Period 4"
    elif time(14, 0) <= now < time(15, 0):
        return "Period 5"
    elif time(15, 0) <= now < time(16, 0):
        return "Period 6"
    elif time(16, 0) <= now < time(17, 0):
        return "Period 7"
    
    # This is for Trial please Skip ok
    elif time(20, 0) <= now < time(21, 0):
        return "Period 8"
    elif time(21, 0) <= now < time(22, 0):
        return "Period 9"
    elif time(22, 0) <= now < time(23, 0):
        return "Period 10"
    elif time(23, 0) <= now or time(0, 0):
        return "Period 11"
    elif time(4, 0) <= now or time(5, 0):
        return "Period 12"
    elif time(5, 0) <= now or time(6, 0):
        return "Period 13"

    return None



def reset_seen_ids_every_hour():
    global seen_ids
    while True:
        now = datetime.now()
        sleep_until = ((now.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)) - now).seconds
        another_time.sleep(sleep_until)
        seen_ids = set()
        print(f"[{datetime.now()}] seen_ids has been reset.")


threading.Thread(target=reset_seen_ids_every_hour, daemon=True).start()


def generate_frames():
    global face_frame
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    while True:
        success, frame = camera.read()
        if not success:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 5)
        if len(faces) > 0:
            with lock:
                face_frame = frame.copy()

        ret, buffer = cv2.imencode('.jpg', frame)
        frame_data = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_data + b'\r\n')


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/process_frame', methods=['POST'])
def process_frame():
    global face_frame, seen_ids
    try:
        data = request.get_json()
        image_data = data['image']
        img_str = re.search(r'base64,(.*)', image_data).group(1)
        img_bytes = base64.b64decode(img_str)
        np_arr = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        face_images = image_preprocessing.preprocessing(img)
        if not face_images:
            return jsonify({"status": "no_face"})

        with lock:
            face_frame = img.copy()

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id, face_emd FROM person_details")
        results = cursor.fetchall()

        current_period = get_current_period()
        
        if not current_period:
            return jsonify({"status": "no_period"})

        for image in face_images:
            features = pred_emb.extracting_embedding(image)
            face_emd = normalize(features).tolist()

            for id, result in results:
                person_face_emb = json.loads(result)
                similarity = cosine_similarity(person_face_emb, face_emd)
                if similarity > 0.65:
                    if id not in seen_ids:
                        print(f"Marking attendance for ID: {id} (Similarity: {similarity:.2f})")
                        seen_ids.add(id)
                        cursor.execute(
                            "INSERT INTO attendance_details (id, period, created_at) VALUES (%s, %s, NOW())",
                            (id, current_period)
                        )

        mysql.connection.commit()
        cursor.close()

        return jsonify({"status": "processed"})

    except Exception as e:
        print("Error in /process_frame:", e)
        return jsonify({"status": "error"})
    
    
@app.route('/attendance_status')
def attendance_status():
    current_period = get_current_period()
    #print(current_period)
    if not current_period:
        flash("No current period is active", "warning")
        return redirect(url_for('index'))

    cursor = mysql.connection.cursor()
    query = """
        SELECT person_details.id,person_details.per_name, 
        MAX(DATE(attendance_details.created_at)) AS date,
        MAX(TIME(attendance_details.created_at)) AS time,
        IF(attendance_details.id IS NULL,"ABSENT","PRESENT") AS status 
        FROM person_details LEFT JOIN attendance_details
        ON person_details.id = attendance_details.id AND attendance_details.period = %s
        GROUP BY person_details.id,person_details.per_name;
        """
    cursor.execute(query, (current_period,))
    result = cursor.fetchall()
    cursor.close()

    return render_template("attendance_status.html", data=result, period=current_period)


@app.route('/add_person', methods=['GET', 'POST'])
def add_person():
    if request.method == 'POST':
        try:
            name = request.form['Name']
            usn = request.form['USN']
            department = request.form['Department']
            image_data = request.form['image']

            img_str = re.search(r'base64,(.*)', image_data).group(1)
            img_bytes = base64.b64decode(img_str)
            np_arr = np.frombuffer(img_bytes, np.uint8)
            img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            face_images = image_preprocessing.preprocessing(img)
            if not face_images:
                return "No face detected", 400

            image = face_images[0]
            features = pred_emb.extracting_embedding(image)
            face_emd = normalize(features).tolist()

            print(f"Image data size: {len(face_emd) / 1024:.2f} KB")


            cursor = mysql.connection.cursor()
            query = "INSERT INTO person_details (per_name, usn, face_emd, dep, created_at) VALUES (%s, %s, %s, %s, %s)"
            created_at = datetime.now()
            cursor.execute(query, (name, usn, json.dumps(face_emd), department, created_at))
            mysql.connection.commit()
            cursor.close()

            return "Image received and saved successfully."

        except Exception as e:
            print("Error:", e)
            return "An error occurred while processing the image."

    return render_template('add_person.html')

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        flash("Please log in first", "warning")
        return redirect(url_for('admin_login'))

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, per_name, usn FROM person_details")
    people = cursor.fetchall()
    cursor.close()

    admin_name = session.get("admin_name", "Admin")  
    return render_template("admin_dashboard.html", people=people, admin_name=admin_name)


@app.route('/delete_person/<int:person_id>', methods=['POST'])
def delete_person(person_id):
    if 'admin_id' not in session:
        flash("Please log in first", "warning")
        return redirect(url_for('admin_login'))

    cursor = mysql.connection.cursor()
    # Delete from attendance_details first to maintain foreign key constraints
    cursor.execute("DELETE FROM attendance_details WHERE id = %s", (person_id,))
    cursor.execute("DELETE FROM person_details WHERE id = %s", (person_id,))
    mysql.connection.commit()
    cursor.close()

    flash("Person deleted successfully", "success")
    return redirect(url_for('admin_dashboard'))



@app.route('/person_attendance/<int:person_id>')
def person_attendance(person_id):
    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT id, DATE(created_at), TIME(created_at), period 
        FROM attendance_details 
        WHERE id = %s
        ORDER BY created_at DESC
    """, (person_id,))
    attendance = cursor.fetchall()

    cursor.execute("SELECT per_name FROM person_details WHERE id = %s", (person_id,))
    person = cursor.fetchone()
    cursor.close()

    return render_template("person_attendance.html", person_id=person_id, person_name=person[0], attendance=attendance)



@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password_input = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM admin_table WHERE username = %s", (username,))
        admin = cursor.fetchone()
        cursor.close()

        if admin and check_password_hash(admin[3], password_input):  
            session['admin_id'] = admin[0]
            flash("Login successful", "success")
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Invalid credentials", "danger")
            return redirect(url_for('admin_login'))

    return render_template("user_login.html")


@app.route('/admin_signup', methods=['GET', 'POST'])
def admin_signup():
    if request.method == 'POST':
        name = request.form['name']
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        try:
            cursor = mysql.connection.cursor()
            cursor.execute("INSERT INTO admin_table (name, username, password) VALUES (%s, %s, %s)",
                           (name, username, hashed_password))
            mysql.connection.commit()
            cursor.close()
            flash("Admin registered successfully. You can now log in.", "success")
            return redirect(url_for('admin_login'))
        except Exception as e:
            print("Signup error:", e)
            flash("Username already exists or invalid input", "danger")

    return render_template("user_signup.html")


@app.route('/attendance_check', methods=['GET', 'POST'])
def attendance_check():
    cursor = mysql.connection.cursor()

    # Get unique dates
    cursor.execute("SELECT DISTINCT DATE(created_at) AS date FROM attendance_details ORDER BY date DESC")
    unique_dates = [row[0] for row in cursor.fetchall()]

    # Get unique periods
    cursor.execute("SELECT DISTINCT period FROM attendance_details WHERE period IS NOT NULL ORDER BY period")
    unique_periods = [row[0] for row in cursor.fetchall()]

    results = []
    selected_date = None
    selected_period = None

    if request.method == 'POST':
        selected_date = request.form['date']
        selected_period = request.form['period']

        query = """
            SELECT 
                person_details.id,
                person_details.per_name,
                MAX(DATE(attendance_details.created_at)) AS date,
                MAX(TIME(attendance_details.created_at)) AS hour,
                IF(attendance_details.id IS NULL, 'ABSENT', 'PRESENT') AS status
            FROM person_details
            LEFT JOIN attendance_details 
                ON person_details.id = attendance_details.id 
                AND attendance_details.period = %s 
                AND DATE(attendance_details.created_at) = %s
            GROUP BY person_details.id, person_details.per_name
        """
        cursor.execute(query, (selected_period, selected_date))
        results = cursor.fetchall()

    cursor.close()
    
    return render_template('attendance_form.html', 
                           unique_dates=unique_dates, 
                           unique_periods=unique_periods, 
                           results=results,
                           selected_date=selected_date,
                           selected_period=selected_period)


@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
